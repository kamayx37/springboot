# 商品管理系统 · 前端工程

课程作业项目：基于 **Vue 3 + Vite 5 + Element Plus** 的商品管理系统前端，
对接后端 `http://localhost:8090`（接口契约见 `API.md`）。

## 一、技术栈

| 分类 | 选型 |
|---|---|
| 框架 | Vue 3（全部使用 `<script setup>` 组合式 API） |
| 构建 | Vite 5 |
| UI | Element Plus（完整引入）+ `@element-plus/icons-vue` |
| 路由 | Vue Router 4（history 模式） |
| 状态 | Pinia（用户 / token / 权限） |
| 请求 | Axios（统一实例 + 响应拦截器） |
| 语言 | 纯 JavaScript（不使用 TypeScript） |

## 二、快速开始

```bash
# 1) 安装依赖
npm install

# 2) 启动开发服务器 → http://localhost:5173
npm run dev

# 3) 生产构建（产物在 dist/）
npm run build

# 4) 预演生产产物 → http://localhost:4173
npm run preview
```

> 若 npm 官方源较慢，可加 `--registry=https://registry.npmmirror.com`。

`vite.config.js` 已配置代理：前端 `/api/**` → `http://localhost:8090`，因此不存在跨域问题。
**后端需要在运行**，否则页面数据请求会提示网络错误（前端本身可正常打开与渲染）。

### 演示账号

| 账号 | 密码 | 角色 | 说明 |
|---|---|---|---|
| `admin` | `admin123` | 超级管理员 | 全部菜单与按钮权限 |
| `product` | `product123` | 商品管理员 | 商品、分类、全文检索 |
| `viewer` | `viewer123` | 只读访客 | 仅查看，无任何写操作按钮 |

登录页的「演示账号」卡片支持点击自动填充。

## 三、目录结构

```
frontend/
├─ index.html
├─ vite.config.js              # 端口 5173 + /api 代理到 8090
├─ package.json
├─ scripts/
│  ├─ e2e-api-check.mjs        # 端到端接口自检脚本（需后端已启动）
│  └─ check-icons.mjs          # 校验 Element Plus 图标名是否正确
└─ src/
   ├─ main.js                  # 应用入口（Element Plus 全量注册 + 图标）
   ├─ App.vue
   ├─ api/                     # 按模块拆分的接口封装
   │  ├─ auth.js  user.js  role.js  permission.js
   │  ├─ category.js  product.js  search.js
   │  └─ indexTask.js  log.js
   ├─ directives/permission.js # v-permission 指令
   ├─ layout/index.vue         # 左侧菜单 + 顶部栏 + 主内容区
   ├─ router/index.js          # 路由表 + 登录/权限守卫
   ├─ stores/user.js           # Pinia：token、用户信息、权限、logout()
   ├─ styles/index.css         # 全局样式（含 .hl 高亮样式）
   ├─ utils/
   │  ├─ request.js            # axios 实例 + 请求/响应拦截器
   │  └─ permission.js         # hasPermission() 权限判断
   └─ views/
      ├─ login/index.vue       # 登录页（含演示账号卡片）
      ├─ dashboard/index.vue   # 仪表盘（在线会话 / ES 索引状态）
      ├─ goods/products.vue    # 商品管理
      ├─ goods/categories.vue  # 分类管理
      ├─ search/index.vue      # 全文检索（高亮 + 重建索引 + 任务轮询）
      ├─ system/users.vue      # 用户管理（分配角色 / 重置密码）
      ├─ system/roles.vue      # 角色管理（权限树分配）
      ├─ system/permissions.vue# 权限管理
      ├─ system/logs.vue       # 操作日志
      └─ error/404.vue
```

## 四、功能清单

### 1. 登录 `/login`
- Element Plus 表单 + 必填/长度校验；成功后 `token`、`userInfo` 同时写入 Pinia 与 localStorage。
- 演示账号提示卡片，点击自动填充用户名/密码。

### 2. 主布局 `/`
- 左侧菜单按权限码动态渲染（如无 `user:view` 则不显示用户管理）。
- 顶部栏显示昵称、角色标签、权限数量；下拉菜单含「修改密码」「退出登录」。
- **退出登录会调用 `POST /api/auth/logout`**，使后端 Redis 中的登录态立即失效，再清理本地状态并跳回 `/login`。
- 刷新页面时从 localStorage 恢复状态，并调用 `GET /api/auth/me` 校验 token 是否仍有效。

### 3. 仪表盘 `/dashboard`
- 欢迎信息、角色/权限统计。
- `GET /api/auth/online` 在线会话数（来自 Redis）。
- `GET /api/index-tasks/overview` Elasticsearch 索引状态（索引名、是否存在、文档数、分词器）+ 最近任务。

### 4. 商品管理 `/goods/products`（`product:view`）
- 筛选：关键词、分类、品牌、状态、价格区间。
- 表格：名称、编码、分类、品牌、价格、库存、销量、状态、创建时间；分页支持切换每页条数。
- 新增/编辑弹窗按后端校验规则（名称必填、编码必填且仅字母数字 `-_`、分类必选、价格/库存 ≥ 0）。
- 新增 `product:create`、编辑 `product:update`、删除 `product:delete` 按权限码控制显隐；删除前二次确认。

### 5. 分类管理 `/goods/categories`（`category:view`）
- 筛选、分页、增删改；表格展示上级分类名称 `parentName` 与商品数 `productCount`。
- 上级分类下拉选择，顶级分类 `parentId = 0`。

### 6. 用户管理 `/system/users`（`user:view`）
- 关键词 + 状态筛选、分页；角色列用 `el-tag` 展示。
- **分配角色**弹窗 → `POST /api/users/assign-roles`。
- 重置密码、删除均二次确认。

### 7. 角色管理 `/system/roles`（`role:view`）
- 分页列表 + 增删改；**分配权限**弹窗使用 `el-tree`（`show-checkbox`、`node-key="id"`、默认勾选 `permissionIds`）。
- 提交时取 `getCheckedKeys().concat(getHalfCheckedKeys())`，保证父级菜单权限不丢失。

### 8. 权限管理 `/system/permissions`（`permission:view`）
- 平铺表格 + 分页 + 类型筛选（MENU / BUTTON / API）；表单含标识、名称、类型、上级权限、路由路径、图标、排序、描述。

### 9. 操作日志 `/system/logs`（`log:view`）
- 筛选：用户名、模块下拉、操作、成功/失败、日期范围。
- 列：操作人、模块、操作、请求方式、请求路径、IP、耗时(ms)、结果、时间；行可展开查看 `params` 与 `errorMessage`。
- 清空日志按钮（`log:clear`）二次确认。

### 10. 全文检索 `/search`（`search:view`）— 演示重点
- 关键词、分类、品牌、状态、价格区间、排序 → `POST /api/search/products`。
- **高亮用 `v-html` 渲染** `nameHighlight` / `brandHighlight` / `descriptionHighlight`
  （后端已注入 `<em class="hl">`），全局样式 `.hl` 为黄底红字加粗。
- 显示「共 N 条结果」、`score` 相关度、分页。
- **重建索引**按钮（`search:rebuild`）→ `POST /api/index-tasks/rebuild`，
  随后轮询任务列表，任务从 `PENDING → RUNNING → SUCCESS` 实时可见。
- 顶部展示 `GET /api/search/status` 的索引名、文档数、分词器。

## 五、权限控制

三种方式组合使用：

1. **菜单**：路由 `meta.permission`，布局组件过滤生成菜单。
2. **按钮**：`v-permission="'product:create'"` 自定义指令，无权限时把元素从 DOM 移除。
3. **页面**：路由守卫校验 `to.meta.permission`，无权访问时提示。

## 六、接口约定与统一处理（`src/utils/request.js`）

- `baseURL = '/api'`，请求头自动携带 `Authorization: Bearer <token>`。
- HTTP 状态码恒为 200，业务状态由 `code` 决定：
  - `code === 200` → 直接 resolve `response.data.data`
  - `code === 401` → 清除本地 token，提示「登录已失效」，跳转 `/login`
  - 其他（403/400/404/409/500…）→ `ElMessage.error(message)` 并 `reject`
- 分页响应统一 `{ records, total, page, size, pages }`。

## 七、自检脚本（可选）

```bash
node scripts/e2e-api-check.mjs     # 端到端接口自检（需后端已启动）
node scripts/check-icons.mjs       # 校验 Element Plus 图标名
```

## 八、构建产物

`npm run build` 输出到 `frontend/dist/`（约 1700 个模块，约 10 秒）。
