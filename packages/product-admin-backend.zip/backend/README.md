# 商品管理系统 — 后端工程（product-admin）

基于 **Spring Boot 3.3.5 + Java 17** 的商品管理系统后端，完整实现课程作业要求的全部技术点：
统一响应 / 参数校验 / 全局异常 / Spring Data JPA / JWT + Redis 登录认证 / RBAC 权限 /
AOP 操作日志 / Elasticsearch 全文检索与高亮 / RabbitMQ 异步索引重建。

---

## 一、技术栈与版本

| 组件 | 版本 | 用途 |
|---|---|---|
| Spring Boot | 3.3.5 | 基础框架 |
| Java | 17 | 运行时 |
| Spring Data JPA + Hibernate | 6.5.3 | ORM 与数据访问 |
| PostgreSQL | 18.6 | 关系型数据库 |
| Redis | 5.0.14 | 登录状态（JWT 白名单） |
| RabbitMQ | 3.13.7（Erlang/OTP 26） | 异步索引重建任务 |
| Elasticsearch | 8.13.4 + analysis-ik 8.13.4 | 全文检索与中文分词 |
| jjwt | 0.12.6 | JWT 签发与校验 |
| Spring Security | 6.1.14 | 认证与鉴权 |

## 二、目录结构

```
backend/
├── pom.xml
└── src/main/
    ├── java/com/example/product/
    │   ├── ProductAdminApplication.java   启动类
    │   ├── common/                        统一响应、分页、异常处理
    │   │   ├── Result.java                统一响应格式 {code,message,data,timestamp}
    │   │   ├── ResultCode.java            响应码枚举
    │   │   ├── PageResult.java            统一分页结构
    │   │   ├── BusinessException.java     业务异常
    │   │   └── GlobalExceptionHandler.java 全局异常处理（@RestControllerAdvice）
    │   ├── config/
    │   │   ├── AppProperties.java         自定义配置绑定
    │   │   ├── SecurityConfig.java        Spring Security + CORS + BCrypt
    │   │   ├── RabbitMQConfig.java        交换机/队列/绑定
    │   │   └── DataInitializer.java       演示数据初始化（幂等）
    │   ├── entity/                        7 张表的 JPA 实体
    │   ├── repository/                    7 个 JPA Repository
    │   ├── dto/                           请求/响应对象（含参数校验注解）
    │   ├── security/
    │   │   ├── JwtUtil.java               JWT 生成/解析（HS256，带 jti）
    │   │   ├── JwtAuthenticationFilter.java  认证过滤器（校验签名 + Redis 白名单）
    │   │   ├── TokenService.java          Redis 登录态读写（product:login:{jti}）
    │   │   ├── LoginUser.java             登录上下文（存 Redis）
    │   │   ├── UserDetailsServiceImpl.java 加载用户/角色/权限
    │   │   ├── RestAuthenticationEntryPoint.java 401 统一 JSON
    │   │   └── RestAccessDeniedHandler.java      403 统一 JSON
    │   ├── aop/
    │   │   ├── OperationLog.java          @OperationLog 注解
    │   │   └── OperationLogAspect.java    切面（异步写库）
    │   ├── service/                       业务服务层
    │   ├── controller/                    9 个 REST 控制器
    │   ├── search/
    │   │   ├── ProductDoc.java            ES 文档模型
    │   │   ├── ProductIndexService.java   索引创建/单条同步/全量重建
    │   │   └── ProductSearchService.java  关键词 + 组合筛选 + 高亮
    │   └── mq/
    │       ├── IndexTaskProducer.java     任务投递
    │       └── IndexTaskConsumer.java     RabbitMQ 消费者（后台执行重建）
    └── resources/application.yml
```

## 三、数据库表（9 张，含 2 张关联表）

| 表名 | 说明 |
|---|---|
| `sys_user` | 用户（密码 BCrypt 密文存储） |
| `sys_role` | 角色 |
| `sys_permission` | 权限（菜单/按钮/接口，树形） |
| `sys_user_role` | 用户-角色关联（JPA `@ManyToMany`） |
| `sys_role_permission` | 角色-权限关联 |
| `sys_operation_log` | 操作日志（AOP 自动写入） |
| `biz_category` | 商品分类 |
| `biz_product` | 商品 |
| `sys_index_task` | ES 索引重建任务 |

> 实际为 9 张（含 2 张关联表）。建表由 `spring.jpa.hibernate.ddl-auto=update` 自动完成。

## 四、启动步骤

### 1. 确认中间件已启动

| 中间件 | 地址 | 检查方式 |
|---|---|---|
| PostgreSQL | 127.0.0.1:5432 | 数据库客户端连接 `product_admin` |
| Redis | 127.0.0.1:6379 | `redis-cli ping` → `PONG` |
| RabbitMQ | 127.0.0.1:5672 / 15672 | 浏览器打开 http://localhost:15672 （guest/guest） |
| Elasticsearch | http://127.0.0.1:9200 | 浏览器看到 JSON 信息 |

### 2. 创建数据库（首次）

```sql
CREATE DATABASE product_admin WITH ENCODING 'UTF8' TEMPLATE template0;
```

### 3. 修改连接配置

编辑 `src/main/resources/application.yml`，确认数据库账号密码与本机一致：

```yaml
spring:
  datasource:
    url: jdbc:postgresql://127.0.0.1:5432/product_admin
    username: nap          # ← 改成你的数据库账号
    password: 201201371    # ← 改成你的数据库密码
```

### 4. 启动

```bash
# 方式一：Maven 直接运行
mvn spring-boot:run

# 方式二：打包后运行
mvn clean package -DskipTests
java -jar target/product-admin-1.0.0.jar
```

启动成功后访问 **http://localhost:8090**。

> **端口说明**：后端使用 **8090** 而不是 8080，因为本机 8080 已被其他程序占用。
> 如需改回 8080，只需修改 `application.yml` 的 `server.port`，并同步修改前端
> `frontend/vite.config.js` 里的代理 `target`。

### 5. 首次启动会自动完成

- 建表（JPA 自动 DDL）
- 初始化权限 35 条、角色 3 个、测试账号 3 个、分类 14 个、商品 60 条
- 尝试把商品同步到 Elasticsearch 索引 `product_index`

## 五、演示账号

| 账号 | 密码 | 角色 | 权限范围 |
|---|---|---|---|
| `admin` | `admin123` | 超级管理员 | 全部 35 项权限 |
| `product` | `product123` | 商品管理员 | 商品、分类、检索、索引重建 |
| `viewer` | `viewer123` | 只读访客 | 仅查看类权限（写操作返回 403） |

> 所有密码均以 **BCrypt 密文**存储，数据库中不存在明文。

## 六、认证与鉴权链路（真实后端链路）

```
POST /api/auth/login
  → 按用户名查库（含角色与权限）
  → BCryptPasswordEncoder.matches() 校验密码
  → 生成 JWT（HS256，payload 含 userId、username、jti）
  → 把用户信息 JSON 写入 Redis：SET product:login:{jti} <json> EX 7200
  → 返回 token

后续每个请求
  → JwtAuthenticationFilter 取 Authorization: Bearer <token>
  → 校验签名与过期时间
  → 查 Redis 是否存在 product:login:{jti}   ← 这一步保证登出立即失效
  → 构建 SecurityContext（权限码作为 GrantedAuthority）

POST /api/auth/logout
  → DEL product:login:{jti}
  → 同一 token 再次访问任何接口都返回 401
```

**手动验证 Redis 登录态：**

```bash
redis-cli keys "product:login:*"          # 查看在线会话
redis-cli get  "product:login:<jti>"      # 查看登录用户信息 JSON
redis-cli del  "product:login:<jti>"      # 手动让 token 失效
```

## 七、RBAC 权限模型

```
用户(sys_user) ──< sys_user_role >── 角色(sys_role) ──< sys_role_permission >── 权限(sys_permission)
```

- 接口级鉴权：`@PreAuthorize("hasAuthority('product:create')")`
- 权限码共 35 个，覆盖 `product:* / category:* / user:* / role:* / permission:* / log:* / search:*`
- 支持「用户分配角色」`POST /api/users/assign-roles`
- 支持「角色分配权限」`POST /api/roles/assign-permissions`

## 八、Elasticsearch 索引

索引名：`product_index`，中文分词器 `ik_max_word`（查询用 `ik_smart`）。

未安装 IK 插件时会自动回退到 `standard` 分词器，不影响功能。

索引字段：`id / name / code / brand / categoryId / categoryName / price / stock / status / sales / description / coverUrl / createdAt`

**检索接口** `POST /api/search/products`：

```json
{
  "keyword": "手机",
  "categoryId": null,
  "brand": null,
  "minPrice": null,
  "maxPrice": null,
  "status": null,
  "page": 1,
  "size": 10,
  "sortField": "_score",
  "sortOrder": "desc"
}
```

响应中的 `nameHighlight` / `descriptionHighlight` / `brandHighlight`
已包含 `<em class="hl">关键词</em>` 标签，前端用 `v-html` 渲染并高亮。

**商品增删改会同步更新索引**，保证搜索结果与数据库一致。

## 九、RabbitMQ 异步索引重建

```
POST /api/index-tasks/rebuild
  → 落库 sys_index_task（状态 PENDING）
  → 投递任务号到 RabbitMQ：exchange=es.index.exchange, routingKey=es.index.rebuild
  → 立即返回任务号（不阻塞请求）

IndexTaskConsumer（@RabbitListener 监听 es.index.rebuild.queue）
  → 状态改为 RUNNING
  → 删除旧索引 → 按 mapping 重建（ik_max_word）→ 批量写入全部商品 → refresh
  → 状态改为 SUCCESS，回写扫描数/成功数/失败数/耗时
```

任务状态查询：`GET /api/index-tasks?page=1&size=10`、`GET /api/index-tasks/{taskNo}`

队列持久化，消费者使用**手动 ACK**，业务失败不重回队列（避免死循环）。

## 十、操作日志（AOP）

在 Controller 写操作方法上标注 `@OperationLog(module="商品管理", operation="新增商品")`，
切面会自动记录：操作人、模块、操作、请求方式、请求路径、请求参数、IP、耗时、成功/失败、异常信息。

日志通过独立的 `@Async` 组件**异步写库**，不会拖慢主业务；记录失败也不会影响业务。

查询接口：`GET /api/operation-logs?page=1&size=10&username=&module=&success=&startDate=&endDate=`

## 十一、统一响应与异常处理

所有接口返回：

```json
{ "code": 200, "message": "操作成功", "data": {}, "timestamp": 1700000000000 }
```

`GlobalExceptionHandler` 统一处理：业务异常、参数校验失败（`@Valid`）、
约束违反、类型不匹配、JSON 解析失败、认证失败、权限不足、数据库唯一约束冲突、兜底异常。

参数校验使用 `jakarta.validation` 注解（`@NotBlank`、`@Min`、`@Pattern`、`@Email`、`@Digits` 等）。

## 十二、接口清单

完整接口契约见工程根目录的 `API.md`，共 50 个接口：认证 4、用户 9、角色 7、权限 7、
分类 6、商品 7、检索 3、索引任务 4、操作日志 3。

## 十三、常见问题

**Q：启动报数据库连接失败？**
A：确认 PostgreSQL 服务在运行、数据库 `product_admin` 已创建、`application.yml` 里的账号密码正确。

**Q：搜索没有结果？**
A：确认 Elasticsearch 已启动（http://localhost:9200 能看到 JSON），然后在「全文检索」页面点
「重建索引」，或调用 `POST /api/index-tasks/rebuild`。

**Q：RabbitMQ 连接失败？**
A：确认 RabbitMQ 服务已启动（15672 管理页可打开）。RabbitMQ 需要 Erlang 运行时。

**Q：索引创建日志提示「回退 standard」？**
A：说明 Elasticsearch 未安装 IK 分词插件，属正常回退，功能不受影响。安装 IK 后重启 ES 即可。
